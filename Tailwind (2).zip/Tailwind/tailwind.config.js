/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  darkMode,
  theme: {
    extend: {},
  },
  plugins: [],
}

